# Desafio DIO — Integrando Dados com MySQL Azure e Transformando com Power BI

Projeto prático de integração entre Azure Database for MySQL e Power BI, com validação e transformação de dados no Power Query.

## Objetivo

Construir o fluxo: **MySQL no Azure → Power BI → Power Query → Modelo de dados → Relatório**.

A base COMPANY contém colaboradores, departamentos, localizações, projetos, horas trabalhadas e dependentes.

## Tecnologias
- Azure Database for MySQL Flexible Server
- MySQL / MySQL Workbench
- Power BI Desktop
- Power Query (M)
- GitHub

## Transformações realizadas
- Revisão de cabeçalhos e tipos de dados.
- `Salary` tratado como número decimal.
- Análise dos valores nulos.
- Validação de colaboradores sem gerente via `Super_ssn`.
- Validação de departamentos sem gerente via `Mgr_ssn`.
- Verificação das horas dos projetos.
- Separação de `Address` em número, rua, cidade e estado.
- Mescla `employee` + `department` por `Dno = Dnumber` usando **Left Outer**, pois `employee` é a tabela base e todos os colaboradores devem ser preservados.
- Self-join de `employee` para obter o nome dos gerentes.
- Mescla de nome e sobrenome em `EmployeeName` e `ManagerName`.
- Combinação de departamento e localização para identificação da combinação departamento-local.
- Agrupamento para análise da quantidade de colaboradores por gerente.
- Eliminação de campos desnecessários para o relatório.

## Mesclar x Atribuir
Neste caso usamos **Mesclar (Merge)** porque precisamos relacionar registros de tabelas diferentes por uma chave e trazer colunas correspondentes. **Atribuir (Append)** seria usado para empilhar linhas de tabelas com estrutura semelhante.

## Execução
1. Criar o Azure Database for MySQL.
2. Configurar firewall/acesso.
3. Conectar pelo MySQL Workbench.
4. Executar `database/company_db.sql`.
5. No Power BI Desktop: **Obter Dados → MySQL database**.
6. Conectar ao banco criado no Azure.
7. Aplicar as transformações do Power Query.
8. Criar o modelo e o relatório.
9. Publicar no Power BI Service, se disponível.

## Arquivos
- `database/company_db.sql` — criação e carga da base MySQL.
- `power_query/transformacoes_employee.pq` — transformações principais em Power Query.
- `docs/fluxo-do-projeto.md` — resumo do fluxo e das junções.

## Segurança
Não publique senhas, strings privadas, chaves ou credenciais do Azure no GitHub.

## Autor
**Wilton Marques**
