CREATE DATABASE IF NOT EXISTS company_db;
USE company_db;
DROP TABLE IF EXISTS dependent;
DROP TABLE IF EXISTS works_on;
DROP TABLE IF EXISTS project;
DROP TABLE IF EXISTS dept_locations;
DROP TABLE IF EXISTS employee;
DROP TABLE IF EXISTS department;

CREATE TABLE employee (
 Fname VARCHAR(20) NOT NULL, Minit CHAR(1), Lname VARCHAR(20) NOT NULL,
 Ssn CHAR(9) PRIMARY KEY, Bdate DATE, Address VARCHAR(100), Sex CHAR(1),
 Salary DECIMAL(12,2), Super_ssn CHAR(9), Dno INT
);
CREATE TABLE department (
 Dname VARCHAR(30) NOT NULL, Dnumber INT PRIMARY KEY, Mgr_ssn CHAR(9), Mgr_start_date DATE
);
CREATE TABLE dept_locations (Dnumber INT, Dlocation VARCHAR(30), PRIMARY KEY (Dnumber,Dlocation));
CREATE TABLE project (Pname VARCHAR(30) NOT NULL, Pnumber INT PRIMARY KEY, Plocation VARCHAR(30), Dnum INT NOT NULL);
CREATE TABLE works_on (Essn CHAR(9), Pno INT, Hours DECIMAL(5,1), PRIMARY KEY (Essn,Pno));
CREATE TABLE dependent (Essn CHAR(9), Dependent_name VARCHAR(30), Sex CHAR(1), Bdate DATE, Relationship VARCHAR(20), PRIMARY KEY (Essn,Dependent_name));

INSERT INTO employee VALUES
('John','B','Smith','123456789','1965-01-09','731-Fondren-Houston-TX','M',30000,'333445555',5),
('Franklin','T','Wong','333445555','1955-12-08','638-Voss-Houston-TX','M',40000,'888665555',5),
('Alicia','J','Zelaya','999887777','1968-01-19','3321-Castle-Spring-TX','F',25000,'987654321',4),
('Jennifer','S','Wallace','987654321','1941-06-20','291-Berry-Bellaire-TX','F',43000,'888665555',4),
('Ramesh','K','Narayan','666884444','1962-09-15','975-Fire-Oak-Humble-TX','M',38000,'333445555',5),
('Joyce','A','English','453453453','1972-07-31','5631-Rice-Houston-TX','F',25000,'333445555',5),
('Ahmad','V','Jabbar','987987987','1969-03-29','980-Dallas-Houston-TX','M',25000,'987654321',4),
('James','E','Borg','888665555','1937-11-10','450-Stone-Houston-TX','M',55000,NULL,1);
INSERT INTO department VALUES
('Research',5,'333445555','1988-05-22'),('Administration',4,'987654321','1995-01-01'),('Headquarters',1,'888665555','1981-06-19');
INSERT INTO dept_locations VALUES (1,'Houston'),(4,'Stafford'),(5,'Bellaire'),(5,'Sugarland'),(5,'Houston');
INSERT INTO project VALUES
('ProductX',1,'Bellaire',5),('ProductY',2,'Sugarland',5),('ProductZ',3,'Houston',5),
('Computerization',10,'Stafford',4),('Reorganization',20,'Houston',1),('Newbenefits',30,'Stafford',4);
INSERT INTO works_on VALUES
('123456789',1,32.5),('123456789',2,7.5),('666884444',3,40.0),('453453453',1,20.0),
('453453453',2,20.0),('333445555',2,10.0),('333445555',3,10.0),('333445555',10,10.0),
('333445555',20,10.0),('999887777',30,30.0),('999887777',10,10.0),('987987987',10,35.0),
('987987987',30,5.0),('987654321',30,20.0),('987654321',20,15.0),('888665555',20,NULL);
INSERT INTO dependent VALUES
('333445555','Alice','F','1986-04-05','Daughter'),('333445555','Theodore','M','1983-10-05','Son'),
('333445555','Joy','F','1958-05-03','Spouse'),('987654321','Abner','M','1942-02-28','Spouse'),
('123456789','Michael','M','1988-01-04','Son'),('123456789','Alice','F','1988-12-30','Daughter'),
('123456789','Elizabeth','M','1967-05-05','Spouse');

ALTER TABLE employee ADD CONSTRAINT fk_employee_supervisor FOREIGN KEY (Super_ssn) REFERENCES employee(Ssn);
ALTER TABLE employee ADD CONSTRAINT fk_employee_department FOREIGN KEY (Dno) REFERENCES department(Dnumber);
ALTER TABLE department ADD CONSTRAINT fk_department_manager FOREIGN KEY (Mgr_ssn) REFERENCES employee(Ssn);
ALTER TABLE dept_locations ADD CONSTRAINT fk_location_department FOREIGN KEY (Dnumber) REFERENCES department(Dnumber);
ALTER TABLE project ADD CONSTRAINT fk_project_department FOREIGN KEY (Dnum) REFERENCES department(Dnumber);
ALTER TABLE works_on ADD CONSTRAINT fk_work_employee FOREIGN KEY (Essn) REFERENCES employee(Ssn);
ALTER TABLE works_on ADD CONSTRAINT fk_work_project FOREIGN KEY (Pno) REFERENCES project(Pnumber);
ALTER TABLE dependent ADD CONSTRAINT fk_dependent_employee FOREIGN KEY (Essn) REFERENCES employee(Ssn);

-- Validações do desafio
SELECT * FROM employee WHERE Super_ssn IS NULL;
SELECT * FROM department WHERE Mgr_ssn IS NULL;
SELECT * FROM works_on WHERE Hours IS NULL OR Hours < 0;
SELECT p.Pname, SUM(w.Hours) AS Total_Hours FROM project p LEFT JOIN works_on w ON p.Pnumber=w.Pno GROUP BY p.Pname;
