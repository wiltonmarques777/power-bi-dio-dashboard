# Fluxo do projeto

Azure Database for MySQL → MySQL Workbench → banco COMPANY → Power BI Desktop → Power Query → tratamento → modelo → relatório.

## Junção Employee + Department
`Employee[Dno]` → `Department[Dnumber]`

Tipo: **Left Outer**, porque `employee` é a tabela base e todos os colaboradores devem permanecer no resultado.

## Self-join Employee + Manager
`Employee[Super_ssn]` → `Employee[Ssn]`

Objetivo: trazer o nome do gerente de cada colaborador.

## Mesclar x Atribuir
Mesclar relaciona registros por uma chave. Atribuir empilha linhas de consultas com estrutura semelhante. Por isso, para trazer dados do departamento e do gerente, a operação correta é Mesclar.
